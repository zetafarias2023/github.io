-- 166 STUDIO v2 — ejecutar en un proyecto Supabase nuevo o adaptar con backup previo.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  role text not null default 'producer' check (role in ('producer','admin')),
  producer_status text not null default 'pending' check (producer_status in ('pending','approved','suspended')),
  verified boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.beats (
  id uuid primary key default gen_random_uuid(),
  producer_id uuid not null references public.profiles(id),
  title text not null,
  genre text not null,
  bpm integer check (bpm is null or bpm between 40 and 250),
  musical_key text,
  price_usd numeric(10,2) not null default 0 check (price_usd >= 0),
  license text not null default 'Basic Lease',
  preview_path text,
  storage_path text not null,
  is_free boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  constraint free_price_consistency check ((is_free and price_usd = 0) or (not is_free and price_usd > 0))
);

create table if not exists public.purchases (
  id uuid primary key default gen_random_uuid(),
  paypal_order_id text unique not null,
  capture_id text,
  beat_id uuid not null references public.beats(id),
  buyer_id uuid references auth.users(id),
  payer_email text,
  amount_usd numeric(10,2) not null,
  status text not null,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,email,display_name)
  values(new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name','Nuevo productor'))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.beats enable row level security;
alter table public.purchases enable row level security;

drop policy if exists "Public profiles are visible" on public.profiles;
drop policy if exists "Users read own profile" on public.profiles;
create policy "Users read own profile" on public.profiles for select using (auth.uid()=id);
drop policy if exists "Users update own display name" on public.profiles;
-- No se permite UPDATE directo en profiles: roles, aprobación y verificación
-- solo se modifican desde endpoints de administración con service role.

drop policy if exists "Published approved beats readable" on public.beats;
create policy "Published approved beats readable" on public.beats for select using (
  published=true and exists(select 1 from public.profiles p where p.id=producer_id and p.producer_status='approved')
);
drop policy if exists "Producers read own beats" on public.beats;
create policy "Producers read own beats" on public.beats for select using (auth.uid()=producer_id);
drop policy if exists "No public purchase reads" on public.purchases;
-- Compras solo desde rutas de servidor con service role.

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('beat-files','beat-files',false,52428800,array['audio/mpeg','audio/wav','audio/x-wav'])
on conflict(id) do update set public=false, file_size_limit=52428800;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('beat-previews','beat-previews',true,12582912,array['audio/mpeg'])
on conflict(id) do update set public=true, file_size_limit=12582912;

-- IMPORTANTE: luego de registrarte con tu email, convertí TU perfil en admin:
-- update public.profiles set role='admin', producer_status='approved', verified=true
-- where email='TU_EMAIL';
-- No habilites registro público de roles admin. El alta de productores es siempre producer/pending.
