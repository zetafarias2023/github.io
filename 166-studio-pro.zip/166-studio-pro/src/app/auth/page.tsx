import AuthForm from "../ui/AuthForm";
export default function AuthPage() {
  return <main className="auth-shell"><a className="logo" href="/">166 <span>STUDIO</span></a><AuthForm /></main>;
}
