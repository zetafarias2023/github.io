import type { Metadata, Viewport } from "next";
import "./globals.css";
import PWARegister from "./ui/PWARegister";

export const metadata: Metadata = {
  title: "166 STUDIO — Beat Store",
  description: "Beats originales, licencias y descargas digitales.",
  applicationName: "166 STUDIO",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "166 STUDIO" }
};
export const viewport: Viewport = {
  themeColor: "#090a0f",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}<PWARegister /></body></html>;
}