import { redirect } from "next/navigation";
import { createSupabaseServer } from "@/lib/supabase-server";
import { supabaseAdmin } from "@/lib/supabase";

export const dynamic = "force-dynamic";
export default async function DashboardPage() {
  const supabase = await createSupabaseServer();
  const { data:{ user } } = await supabase.auth.getUser();
  if (!user) redirect("/auth");
  const { data: profile } = await supabase.from("profiles").select("id,email,display_name,role,producer_status,verified").eq("id",user.id).single();
  if (!profile) redirect("/auth");
  const { data: beats } = await supabase.from("beats").select("*").eq("producer_id",user.id).order("created_at",{ascending:false});
  let producers:any[] = [];
  if (profile.role === "admin") {
    const { data } = await supabaseAdmin().from("profiles").select("id,email,display_name,role,producer_status,verified").order("created_at",{ascending:false});
    producers = data || [];
  }
  return <DashboardClient profile={profile} beats={beats||[]} producers={producers}/>;
}
