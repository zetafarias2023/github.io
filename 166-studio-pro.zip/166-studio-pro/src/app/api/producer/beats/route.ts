import { NextResponse } from "next/server";
import { createSupabaseServer } from "@/lib/supabase-server";
import { supabaseAdmin } from "@/lib/supabase";
import { randomUUID } from "crypto";

export const runtime = "nodejs";
export async function POST(req:Request) {
  try {
    const auth=await createSupabaseServer();
    const {data:{user}}=await auth.auth.getUser();
    if(!user) return NextResponse.json({error:"Iniciá sesión."},{status:401});
    const {data:profile}=await auth.from("profiles").select("role,producer_status").eq("id",user.id).single();
    if(!profile || (profile.role!=="admin" && profile.producer_status!=="approved"))
      return NextResponse.json({error:"Tu cuenta todavía no está aprobada para subir beats."},{status:403});
    const form=await req.formData();
    const title=String(form.get("title")||"").trim();
    const genre=String(form.get("genre")||"").trim();
    const price=Number(form.get("price_usd")||0);
    const audio=form.get("audio");
    const preview=form.get("preview");
    if(!title||!genre||!(audio instanceof File)||!["audio/mpeg","audio/wav","audio/x-wav"].includes(audio.type)||audio.size>50*1024*1024)
      return NextResponse.json({error:"Datos inválidos. MP3/WAV hasta 50 MB."},{status:400});
    if(!Number.isFinite(price)||price<0||price>10000) return NextResponse.json({error:"Precio inválido."},{status:400});
    const admin=supabaseAdmin();
    const ext=audio.name.toLowerCase().endsWith(".wav")?"wav":"mp3";
    const path=`${user.id}/${randomUUID()}.${ext}`;
    const {error:upErr}=await admin.storage.from("beat-files").upload(path,audio,{contentType:audio.type,upsert:false});
    if(upErr) throw upErr;
    let previewPath:string|null=null;
    if(preview instanceof File && preview.size>0) {
      if(preview.type!=="audio/mpeg"||preview.size>12*1024*1024) return NextResponse.json({error:"El preview debe ser MP3 de hasta 12 MB."},{status:400});
      previewPath=`${user.id}/${randomUUID()}.mp3`;
      const {error}=await admin.storage.from("beat-previews").upload(previewPath,preview,{contentType:"audio/mpeg"});
      if(error) throw error;
      previewPath=admin.storage.from("beat-previews").getPublicUrl(previewPath).data.publicUrl;
    }
    const isFree=price===0;
    const {error}=await admin.from("beats").insert({
      producer_id:user.id,title,genre,bpm:form.get("bpm")?Number(form.get("bpm")):null,
      musical_key:String(form.get("musical_key")||"")||null,price_usd:price,is_free:isFree,
      license:String(form.get("license")||"Basic Lease"),storage_path:path,preview_path:previewPath,
      published:form.get("published")==="on"||form.get("published")==="true"
    });
    if(error) throw error;
    return NextResponse.json({ok:true});
  } catch(e:any) { return NextResponse.json({error:e?.message||"Error al guardar beat."},{status:500}); }
}
