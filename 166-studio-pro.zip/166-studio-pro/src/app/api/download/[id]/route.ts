import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function GET(_req: Request, ctx: { params: Promise<{id:string}> }) {
  try {
    const { id } = await ctx.params;
    const db = supabaseAdmin();
    const { data: beat, error } = await db.from("beats").select("id,is_free,published,storage_path").eq("id",id).single();
    if (error || !beat || !beat.published || !beat.is_free) return NextResponse.json({ error:"Este beat no es gratuito o no está publicado." }, { status:403 });
    const { data, error:signError } = await db.storage.from("beat-files").createSignedUrl(beat.storage_path, 60*60);
    if (signError || !data) return NextResponse.json({ error:"No se pudo preparar la descarga." }, { status:500 });
    return NextResponse.json({ downloadUrl:data.signedUrl });
  } catch { return NextResponse.json({ error:"Error interno." }, { status:500 }); }
}