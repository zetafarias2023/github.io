import { NextResponse } from "next/server";
import { createSupabaseServer } from "@/lib/supabase-server";
import { supabaseAdmin } from "@/lib/supabase";

export async function PATCH(req:Request) {
  const auth=await createSupabaseServer();
  const {data:{user}}=await auth.auth.getUser();
  if(!user) return NextResponse.json({error:"No autorizado."},{status:401});
  const {data:me}=await auth.from("profiles").select("role").eq("id",user.id).single();
  if(me?.role!=="admin") return NextResponse.json({error:"Solo administradores."},{status:403});
  const {id,action}=await req.json();
  if(!id||!["approve","verify","suspend"].includes(action)) return NextResponse.json({error:"Solicitud inválida."},{status:400});
  const db=supabaseAdmin();
  const patch=action==="approve"?{producer_status:"approved"}:action==="verify"?{verified:true}:{producer_status:"suspended"};
  const {error}=await db.from("profiles").update(patch).eq("id",id).neq("role","admin");
  if(error) return NextResponse.json({error:error.message},{status:500});
  return NextResponse.json({ok:true});
}
