import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { paypalAccessToken, paypalBase } from "@/lib/paypal";

export async function POST(req: Request) {
  try {
    const { beatId } = await req.json();
    if (!beatId) return NextResponse.json({ error:"Falta beatId." }, { status:400 });
    const db = supabaseAdmin();
    const { data: beat, error } = await db.from("beats").select("id,title,price_usd,is_free,published").eq("id",beatId).single();
    if (error || !beat || !beat.published || beat.is_free || Number(beat.price_usd) <= 0)
      return NextResponse.json({ error:"Beat no disponible para compra." }, { status:404 });
    const token = await paypalAccessToken();
    const response = await fetch(`${paypalBase()}/v2/checkout/orders`, {
      method:"POST", headers:{ Authorization:`Bearer ${token}`, "Content-Type":"application/json" },
      body:JSON.stringify({ intent:"CAPTURE", purchase_units:[{ reference_id:String(beat.id), custom_id:String(beat.id), description:beat.title, amount:{ currency_code:"USD", value:Number(beat.price_usd).toFixed(2) } }] }),
      cache:"no-store"
    });
    const order = await response.json();
    if (!response.ok) return NextResponse.json({ error:"PayPal no pudo crear la orden.", details:order }, { status:502 });
    return NextResponse.json({ id:order.id });
  } catch (e) { return NextResponse.json({ error:"Error interno al iniciar el pago." }, { status:500 }); }
}