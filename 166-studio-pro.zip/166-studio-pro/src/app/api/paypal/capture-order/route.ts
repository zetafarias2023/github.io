import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";
import { paypalAccessToken, paypalBase } from "@/lib/paypal";

export async function POST(req: Request) {
  try {
    const { orderID, beatId } = await req.json();
    if (!orderID || !beatId) return NextResponse.json({ error:"Faltan datos de la orden." }, { status:400 });
    const db = supabaseAdmin();
    const { data: beat, error } = await db.from("beats").select("id,title,price_usd,is_free,published,storage_path").eq("id",beatId).single();
    if (error || !beat || !beat.published || beat.is_free) return NextResponse.json({ error:"Beat no disponible." }, { status:404 });
    const token = await paypalAccessToken();
    const response = await fetch(`${paypalBase()}/v2/checkout/orders/${encodeURIComponent(orderID)}/capture`, {
      method:"POST", headers:{ Authorization:`Bearer ${token}`, "Content-Type":"application/json" }, body:"{}", cache:"no-store"
    });
    const capture = await response.json();
    if (!response.ok || capture.status !== "COMPLETED") return NextResponse.json({ error:"PayPal no confirmó el pago.", details:capture }, { status:402 });
    const unit = capture.purchase_units?.[0];
    const captured = unit?.payments?.captures?.[0];
    const amount = captured?.amount;
    if (String(unit?.custom_id) !== String(beat.id) || amount?.currency_code !== "USD" || Number(amount?.value) !== Number(beat.price_usd))
      return NextResponse.json({ error:"No coincide el importe o el producto. Contactá soporte." }, { status:400 });
    const payerEmail = capture.payer?.email_address || null;
    await db.from("purchases").upsert({ paypal_order_id:orderID, beat_id:beat.id, payer_email:payerEmail, capture_id:captured.id, amount_usd:Number(beat.price_usd), status:"completed" }, { onConflict:"paypal_order_id" });
    const { data: signed, error:signedError } = await db.storage.from("beat-files").createSignedUrl(beat.storage_path, 60*60);
    if (signedError || !signed?.signedUrl) return NextResponse.json({ error:"Pago confirmado. La descarga necesita asistencia del productor." }, { status:200 });
    return NextResponse.json({ status:"COMPLETED", downloadUrl:signed.signedUrl });
  } catch { return NextResponse.json({ error:"Error interno al confirmar el pago." }, { status:500 }); }
}