"use client";
import { useState } from "react";
import { createSupabaseBrowser } from "@/lib/supabase-browser";

export default function AuthForm() {
  const [mode,setMode] = useState<"login"|"signup">("login");
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [name,setName] = useState("");
  const [message,setMessage] = useState("");
  const [busy,setBusy] = useState(false);
  async function submit(e:React.FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    const supabase = createSupabaseBrowser();
    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({
        email, password,
        options: { data: { display_name: name }, emailRedirectTo: `${window.location.origin}/auth/callback` }
      });
      setMessage(error ? error.message : "Cuenta creada. Revisá tu email para confirmar el registro y luego iniciá sesión.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) setMessage(error.message);
      else window.location.href = "/dashboard";
    }
    setBusy(false);
  }
  return <section className="auth-card">
    <p className="eyebrow">166 STUDIO ACCOUNT</p><h1>{mode==="login"?"Bienvenido de nuevo":"Unite a 166 STUDIO"}</h1>
    <p className="muted">Entrá a tu espacio de productor y administrá tus instrumentales.</p>
    <form onSubmit={submit}>
      {mode==="signup" && <label>Nombre artístico<input required value={name} onChange={e=>setName(e.target.value)} placeholder="Tu nombre de productor"/></label>}
      <label>Email<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="tu@email.com"/></label>
      <label>Contraseña<input required minLength={8} type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo 8 caracteres"/></label>
      <button className="primary full" disabled={busy}>{busy?"Procesando...":mode==="login"?"INICIAR SESIÓN":"CREAR CUENTA"}</button>
    </form>
    {message && <p className="notice">{message}</p>}
    <button className="text-button" onClick={()=>{setMode(mode==="login"?"signup":"login");setMessage("");}}>{mode==="login"?"¿No tenés cuenta? Registrate":"Ya tengo cuenta. Iniciar sesión"}</button>
  </section>;
}
