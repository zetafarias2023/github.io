"use client";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import { useState } from "react";

type Beat = { id: string; title: string; genre: string; bpm: number|null; musical_key: string|null; price_usd: number; license: string; preview_path: string|null; is_free: boolean };

export default function BeatCard({ beat }: { beat: Beat }) {
  const [message, setMessage] = useState("");
  const [downloadUrl, setDownloadUrl] = useState("");
  const clientId = process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID;
  async function createOrder() {
    const res = await fetch("/api/paypal/create-order", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ beatId:beat.id }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "No se pudo crear la orden.");
    return data.id;
  }
  async function onApprove(data: { orderID: string }) {
    const res = await fetch("/api/paypal/capture-order", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({ orderID:data.orderID, beatId:beat.id }) });
    const result = await res.json();
    if (!res.ok) { setMessage(result.error || "No se pudo confirmar el pago."); return; }
    setDownloadUrl(result.downloadUrl);
    setMessage("Pago confirmado. Tu descarga está lista.");
  }
  async function freeDownload() {
    const res = await fetch(`/api/download/${beat.id}`);
    const data = await res.json();
    if (!res.ok) { setMessage(data.error || "Descarga no disponible."); return; }
    setDownloadUrl(data.downloadUrl);
    setMessage("Tu descarga está lista.");
  }
  return <article className="beat">
    <div className="art"><span className="artnum">166</span><span className="artlabel">{beat.is_free ? "FREE DOWNLOAD" : "INSTRUMENTAL"}</span></div>
    <div className="beatbody"><div className="beattop"><div><h3>{beat.title}</h3><p>{beat.genre} · {beat.bpm ?? "—"} BPM · {beat.musical_key || "—"}</p></div><strong>{beat.is_free ? "FREE" : `$${Number(beat.price_usd).toFixed(2)}`}</strong></div>
      <p className="license">{beat.license}</p>
      {beat.preview_path && <audio controls preload="none" src={beat.preview_path}/>}
      {beat.is_free ? <button className="primary full" onClick={freeDownload}>DOWNLOAD FREE ↓</button> :
        clientId ? <PayPalScriptProvider options={{ clientId, currency:"USD", intent:"capture" }}><PayPalButtons style={{layout:"vertical",label:"paypal",shape:"rect",height:42}} createOrder={createOrder} onApprove={onApprove} onError={()=>setMessage("Error con PayPal. Intentá nuevamente.")}/></PayPalScriptProvider>
        : <p className="hint">Falta configurar NEXT_PUBLIC_PAYPAL_CLIENT_ID.</p>}
      {downloadUrl && <a className="download" href={downloadUrl} target="_blank" rel="noreferrer">Descargar archivo seguro ↗</a>}
      {message && <p className="status">{message}</p>}
    </div>
  </article>;
}