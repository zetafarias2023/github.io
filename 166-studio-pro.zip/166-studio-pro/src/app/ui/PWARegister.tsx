"use client";
import { useEffect, useState } from "react";

export default function PWARegister() {
  const [prompt, setPrompt] = useState<any>(null);
  const [show, setShow] = useState(false);
  useEffect(() => {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(() => {});
    const handler = (event: Event) => {
      event.preventDefault();
      setPrompt(event);
      setShow(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    const installed = () => setShow(false);
    window.addEventListener("appinstalled", installed);
    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installed);
    };
  }, []);
  async function install() {
    if (!prompt) return;
    await prompt.prompt();
    setPrompt(null);
    setShow(false);
  }
  return show ? <button className="installapp" onClick={install}>＋ Instalar 166 STUDIO</button> : null;
}