"use client";
import { useState } from "react";
import { createSupabaseBrowser } from "@/lib/supabase-browser";

export default function DashboardClient({profile,beats,producers}:{profile:any;beats:any[];producers:any[]}) {
  const [msg,setMsg]=useState("");
  const [busy,setBusy]=useState(false);
  const isAdmin=profile.role==="admin";
  async function signOut(){await createSupabaseBrowser().auth.signOut();window.location.href="/";}
  async function upload(e:React.FormEvent<HTMLFormElement>){
    e.preventDefault();setBusy(true);setMsg("");
    const formElement=e.currentTarget;
    const form=new FormData(formElement);
    const res=await fetch("/api/producer/beats",{method:"POST",body:form});
    const data=await res.json();setMsg(res.ok?"Beat guardado. Actualizá la página para verlo.":(data.error||"No se pudo subir."));
    setBusy(false);if(res.ok)formElement.reset();
  }
  async function producerAction(id:string,action:"approve"|"verify"|"suspend"){
    const res=await fetch("/api/admin/producers",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,action})});
    const d=await res.json();setMsg(res.ok?"Cambio aplicado. Recargá para ver el estado.":d.error);
  }
  return <main className="dash-shell">
    <header className="nav"><a className="logo" href="/">166 <span>STUDIO</span></a><div className="dash-user">{profile.display_name||profile.email} · {isAdmin?"ADMIN":"PRODUCTOR"} <button className="text-button" onClick={signOut}>Cerrar sesión</button></div></header>
    <section className="dash-head"><p className="eyebrow">CREATOR WORKSPACE</p><h1>Panel de {isAdmin?"administración":"productor"}</h1><p className="muted">Gestioná tu catálogo, publicaciones y perfil dentro de 166 STUDIO.</p>
      <span className="status">{profile.producer_status==="approved"?"PRODUCTOR APROBADO":profile.producer_status==="pending"?"SOLICITUD PENDIENTE":"CUENTA"} {profile.verified?" · ✓ VERIFICADO":""}</span>
    </section>
    {msg&&<p className="notice">{msg}</p>}
    {profile.producer_status!=="approved"&&!isAdmin?<div className="panel"><h2>Tu cuenta está pendiente de aprobación</h2><p className="muted">El equipo de 166 STUDIO revisará tu solicitud. Cuando sea aprobada podrás subir y publicar instrumentales.</p></div>:<div className="dash-grid">
      <section className="panel"><h2>Subir un beat</h2><form onSubmit={upload} className="upload-form">
        <label>Título<input name="title" required maxLength={90}/></label>
        <label>Género<input name="genre" required placeholder="Trap, drill, reggaeton..."/></label>
        <div className="two"><label>BPM<input name="bpm" type="number" min="40" max="250"/></label><label>Tonalidad<input name="musical_key" placeholder="Am, C#..."/></label></div>
        <label>Precio USD (0 = gratis)<input name="price_usd" type="number" min="0" step="0.01" defaultValue="0" required/></label>
        <label>Licencia<input name="license" defaultValue="Basic Lease" required/></label>
        <label>Archivo master (MP3/WAV)<input name="audio" type="file" accept=".mp3,.wav,audio/mpeg,audio/wav" required/></label>
        <label>Preview (opcional MP3)<input name="preview" type="file" accept=".mp3,audio/mpeg"/></label>
        <label className="checkline"><input name="published" type="checkbox"/> Publicar inmediatamente (si está aprobado)</label>
        <button className="primary full" disabled={busy}>{busy?"Subiendo...":"SUBIR BEAT"}</button>
      </form></section>
      <section className="panel"><h2>Tu catálogo <span className="count">{beats.length}</span></h2>{beats.length?beats.map(b=><div className="beat-row" key={b.id}><div><b>{b.title}</b><small>{b.genre} · {b.is_free?"GRATIS":`$${b.price_usd} USD`} · {b.published?"PUBLICADO":"BORRADOR"}</small></div></div>):<p className="muted">Todavía no subiste instrumentales.</p>}</section>
    </div>}
    {isAdmin&&<section className="panel admin-panel"><p className="eyebrow">ADMIN CONTROL</p><h2>Productores y verificaciones</h2>{producers.map(p=><div className="producer-row" key={p.id}><div><b>{p.display_name||p.email}</b><small>{p.email} · {p.role} · {p.producer_status} {p.verified?"· VERIFIED":""}</small></div><div className="actions">{p.role!=="admin"&&<><button onClick={()=>producerAction(p.id,"approve")}>Aprobar</button><button onClick={()=>producerAction(p.id,"verify")}>{p.verified?"Quitar verificado":"Verificar"}</button><button onClick={()=>producerAction(p.id,"suspend")}>Suspender</button></>}</div></div>)}</section>}
  </main>;
}
