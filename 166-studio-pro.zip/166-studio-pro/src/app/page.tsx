import { supabasePublic } from "@/lib/supabase";
import BeatCard from "./ui/BeatCard";
import PWARegister from "./ui/PWARegister";

export const dynamic = "force-dynamic";
export default async function Home() {
  let beats:any[]=[];
  try {
    const {data}=await supabasePublic().from("beats")
      .select("id,title,genre,bpm,musical_key,price_usd,license,preview_path,is_free,producer_id,profiles(display_name,verified)")
      .eq("published",true).order("created_at",{ascending:false});
    beats=data||[];
  } catch {}
  return <main className="shell">
    <header className="nav"><a className="logo" href="/">166 <span>STUDIO</span></a><nav><a href="#beats">Beats</a><a href="#about">Productores</a></nav><div className="nav-right"><a href="/auth">Ingresar</a><a className="navcta" href="/dashboard">Mi panel ↗</a></div></header>
    <section className="hero"><div><p className="eyebrow">INDEPENDENT BEAT MARKETPLACE</p><h1>Your next hit<br/>starts with a <em>beat.</em></h1><p className="sub">Instrumentales originales de productores independientes. Escuchá, elegí tu licencia y descargá.</p><a className="primary" href="#beats">EXPLORAR BEATS <span>↗</span></a>
    <div className="stats"><div><b>{beats.length.toString().padStart(2,"0")}</b><small>BEATS ONLINE</small></div><div><b>24/7</b><small>DESCARGAS DIGITALES</small></div><div><b>USD</b><small>GLOBAL STORE</small></div></div></div>
    <aside className="feature"><div className="featuremark">166</div><span className="verified">✓ CREATOR MARKETPLACE</span><h2>166 Studio</h2><p>Sound made for the next generation.</p><div className="wave">▂ ▅ ▃ ▇ ▄ ▆ ▂ ▅ ▃ ▇ ▄ ▆ ▂ ▅ ▃</div></aside></section>
    <section id="beats" className="catalog"><div className="sectiontop"><div><p className="eyebrow">THE COLLECTION</p><h2>Latest beats</h2><p className="muted">Elegí tu instrumental y encontrá la licencia ideal.</p></div><span className="tag">DIGITAL PRODUCTS · USD</span></div>
    {beats.length?<div className="grid">{beats.map(b=><BeatCard key={b.id} beat={b}/>)}</div>:<div className="empty"><h3>El catálogo está listo.</h3><p>Creá tu cuenta, aprobá productores y publicá los primeros beats desde el panel.</p></div>}</section>
    <section id="about" className="about"><div><p className="eyebrow">CREATOR COMMUNITY</p><h2>Un estudio. Muchos sonidos.</h2><p className="muted">Productores independientes pueden crear su perfil y publicar instrumentales luego de la aprobación del equipo. Los perfiles verificados se identifican con un distintivo otorgado por administración.</p><a className="primary" href="/auth">CREAR CUENTA DE PRODUCTOR</a></div><div className="aboutbadge">166<br/><small>STUDIO</small></div></section>
    <footer><b>166 STUDIO</b><span>© {new Date().getFullYear()} · Licencias digitales de beats</span></footer><PWARegister/>
  </main>;
}
