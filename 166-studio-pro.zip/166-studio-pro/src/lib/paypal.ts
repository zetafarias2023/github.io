const base = process.env.PAYPAL_ENV === "live"
  ? "https://api-m.paypal.com"
  : "https://api-m.sandbox.paypal.com";

export async function paypalAccessToken() {
  const id = process.env.PAYPAL_CLIENT_ID;
  const secret = process.env.PAYPAL_CLIENT_SECRET;
  if (!id || !secret) throw new Error("Faltan credenciales PayPal.");
  const auth = Buffer.from(`${id}:${secret}`).toString("base64");
  const response = await fetch(`${base}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
    cache: "no-store"
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error_description || "No se pudo autenticar con PayPal.");
  return data.access_token as string;
}

export function paypalBase() { return base; }